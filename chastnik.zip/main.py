import tkinter as tk
from tkinter import scrolledtext, messagebox, simpledialog, filedialog
import requests
import base64
import json
import hashlib
from io import BytesIO
from PIL import Image, ImageTk
import os

# --- КОНФИГУРАЦИЯ ---
BASE_URL = "https://chastnik-a8157-default-rtdb.firebaseio.com/chastnik"
IMGBB_API_KEY = "A50591db051d07bbd81f1bca1c622607"
DEFAULT_AVATAR = "https://cdn-icons-png.flaticon.com/512/149/149071.png"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SESSION_FILE = os.path.join(BASE_DIR, "session.json")

COLORS = {
    "bg": "#313338", "sidebar": "#1E1F22", "chat_bg": "#2B2D31",
    "text": "#DBDEE1", "accent": "#5865F2", "input": "#1E1F22",
    "green": "#23A55A", "red": "#DA373C", "gray": "#80848E",
    "orange": "#FF6600"
}

def hash_pass(password):
    return hashlib.sha256(password.encode()).hexdigest()

class Network:
    @staticmethod
    def login(username, password, is_hashed=False):
        url = f"{BASE_URL}/users/{username}.json"
        try:
            res = requests.get(url, timeout=5).json()
            if res and "password" in res:
                target_p = password if is_hashed else hash_pass(password)
                return str(res["password"]) == str(target_p)
            return False
        except: return False

    @staticmethod
    def register(username, password):
        url = f"{BASE_URL}/users/{username}.json"
        try:
            if requests.get(url, timeout=5).json() is not None: return "exists"
            data = {"password": hash_pass(password), "avatar": DEFAULT_AVATAR, "friends": {"system": True}}
            return requests.put(url, json=data, timeout=5).status_code == 200
        except: return False

    @staticmethod
    def get_data(path):
        try: return requests.get(f"{BASE_URL}/{path}.json", timeout=5).json() or {}
        except: return {}

    @staticmethod
    def user_exists(username):
        try:
            res = requests.get(f"{BASE_URL}/users/{username}.json", timeout=5).json()
            return res is not None and "password" in res
        except: return False
class ChastnikApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Chastnik")
        w, h = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        self.root.geometry(f"{int(w)}x{int(h)}")
        self.root.configure(bg=COLORS["bg"])
        
        self.user, self.target, self.loop = None, None, False
        self.last_msg_count = 0
        self.container = tk.Frame(self.root, bg=COLORS["bg"])
        self.container.pack(fill="both", expand=True)
        self.check_auto_login()

    def check_auto_login(self):
        if os.path.exists(SESSION_FILE):
            try:
                with open(SESSION_FILE, "r") as f: data = json.load(f)
                if Network.login(data["u"], data["p"], True):
                    self.user = data["u"]; self.show_main(); return
            except: pass
        self.show_login()

    def logout(self):
        if os.path.exists(SESSION_FILE): os.remove(SESSION_FILE)
        self.user = None; self.show_login()

    def clear(self):
        self.loop = False; self.last_msg_count = 0
        for w in self.container.winfo_children(): w.destroy()

    def show_login(self):
        self.clear()
        tk.Label(self.container, text="CHASTNIK", font=("Arial", 32, "bold"), bg=COLORS["bg"], fg=COLORS["orange"]).pack(pady=(80, 40))
        f = tk.Frame(self.container, bg=COLORS["bg"]); f.pack(padx=40, fill="x")
        self.u_in = self.entry(f, "ЛОГИН")
        self.p_in = self.entry(f, "ПАРОЛЬ", True)
        tk.Button(self.container, text="ВХОД", bg=COLORS["accent"], fg="white", font=("Arial", 20, "bold"), command=self.do_login).pack(pady=20, padx=40, fill="x", ipady=15)
        tk.Button(self.container, text="Создать аккаунт", font=("Arial", 14), bg=COLORS["bg"], fg=COLORS["gray"], command=self.do_reg).pack()

    def entry(self, m, l, p=False):
        tk.Label(m, text=l, font=("Arial", 14), bg=COLORS["bg"], fg=COLORS["gray"]).pack(anchor="w")
        e = tk.Entry(m, font=("Arial", 18), bg=COLORS["input"], fg="white", borderwidth=0, insertbackground="white", show="*" if p else "")
        e.pack(fill="x", pady=(5, 15), ipady=12); return e

    def do_login(self):
        u, p = self.u_in.get().strip().lower(), self.p_in.get().strip()
        if Network.login(u, p):
            self.user = u
            with open(SESSION_FILE, "w") as f: json.dump({"u": u, "p": hash_pass(p)}, f)
            self.show_main()
        else: messagebox.showerror("Ошибка", "Неверный логин")

    def do_reg(self):
        u, p = self.u_in.get().strip().lower(), self.p_in.get().strip()
        if len(u) > 2 and Network.register(u, p): messagebox.showinfo("OK", "Готово!")

    def show_main(self):
        self.clear()
        h = tk.Frame(self.container, bg=COLORS["sidebar"], height=80); h.pack(fill="x")
        tk.Label(h, text="Чаты", bg=COLORS["sidebar"], fg="white", font=("Arial", 24, "bold")).pack(side="left", padx=20)
        tk.Button(h, text="+", font=("Arial", 22, "bold"), bg=COLORS["green"], fg="white", command=self.add_friend).pack(side="right", padx=10, pady=10)
        tk.Button(h, text="ПРОФИЛЬ", font=("Arial", 12, "bold"), bg=COLORS["accent"], fg="white", command=self.show_profile).pack(side="right", padx=10, pady=10)
        
        scroll = tk.Frame(self.container, bg=COLORS["bg"]); scroll.pack(fill="both", expand=True)
        u_data = Network.get_data(f"users/{self.user}")
        self.friends_list = u_data.get("friends", {}) # Сохраняем список друзей для проверки
        
        for name in self.friends_list.keys():
            if name == "system": continue
            f = tk.Button(scroll, bg=COLORS["chat_bg"], borderwidth=0, command=lambda n=name: self.show_chat(n))
            f.pack(fill="x", padx=15, pady=5)
            tk.Label(f, text=name, bg=COLORS["chat_bg"], fg="white", font=("Arial", 18, "bold")).pack(side="left", padx=15, pady=20)

    def add_friend(self):
        raw_name = simpledialog.askstring("Друг", "Введите точный ник:")
        if not raw_name: return
        name = raw_name.strip().lower()
        
        if name == self.user:
            messagebox.showwarning("Внимание", "Нельзя добавить самого себя!")
            return
            
        # ПРОВЕРКА НА ДУБЛИКАТ
        if name in self.friends_list:
            messagebox.showwarning("Внимание", f"{name} уже есть в твоих чатах!")
            return
        
        if Network.user_exists(name):
            requests.patch(f"{BASE_URL}/users/{self.user}/friends.json", json={name: True})
            requests.patch(f"{BASE_URL}/users/{name}/friends.json", json={self.user: True})
            self.show_main()
        else:
            messagebox.showerror("Ошибка", "Такого пользователя нет!")

    def show_chat(self, name):
        self.clear(); self.target = name
        top = tk.Frame(self.container, bg=COLORS["sidebar"], height=70); top.pack(fill="x")
        tk.Button(top, text="←", font=("Arial", 20), bg=COLORS["sidebar"], fg="white", command=self.show_main).pack(side="left", padx=15)
        tk.Label(top, text=f"@{name}", bg=COLORS["sidebar"], fg="white", font=("Arial", 18, "bold")).pack(side="left")
        
        inv = tk.Frame(self.container, bg=COLORS["chat_bg"]); inv.pack(fill="x", side="bottom", pady=15, padx=10)
        tk.Button(inv, text="➤", font=("Arial", 18), bg=COLORS["accent"], fg="white", command=self.send).pack(side="right", ipadx=20)
        self.msg = tk.Entry(inv, font=("Arial", 16), bg=COLORS["input"], fg="white", borderwidth=0, insertbackground="white")
        self.msg.pack(side="left", fill="x", expand=True, ipady=12)
        
        self.txt = scrolledtext.ScrolledText(self.container, bg=COLORS["chat_bg"], fg=COLORS["text"], font=("Arial", 16), borderwidth=0)
        self.txt.pack(fill="both", expand=True)
        self.loop = True; self.update_chat()

    def send(self):
        v = self.msg.get().strip(); rid = "_".join(sorted([self.user, self.target]))
        if v: requests.post(f"{BASE_URL}/messages/{rid}.json", json={"u": self.user, "t": v}); self.msg.delete(0, tk.END); self.refresh()

    def refresh(self):
        if not self.target: return
        rid = "_".join(sorted([self.user, self.target]))
        msgs = Network.get_data(f"messages/{rid}")
        if len(msgs) != self.last_msg_count:
            self.txt.config(state="normal"); self.txt.delete("1.0", tk.END)
            for k in sorted(msgs.keys()):
                m = msgs[k]
                p = "Я: " if m['u'] == self.user else f"{m['u']}: "
                self.txt.insert(tk.END, f"{p}{m['t']}\n\n")
            self.txt.config(state="disabled"); self.txt.see(tk.END)
            self.last_msg_count = len(msgs)

    def update_chat(self):
        if self.loop: self.refresh(); self.root.after(2000, self.update_chat)

    def show_profile(self):
        self.clear()
        tk.Label(self.container, text="ПРОФИЛЬ", font=("Arial", 28, "bold"), bg=COLORS["bg"], fg="white").pack(pady=40)
        tk.Label(self.container, text=f"Ник: {self.user}", font=("Arial", 20), bg=COLORS["bg"], fg=COLORS["gray"]).pack(pady=20)
        tk.Button(self.container, text="ВЫЙТИ", bg=COLORS["red"], fg="white", font=("Arial", 14, "bold"), command=self.logout).pack(pady=20, padx=60, fill="x", ipady=10)
        tk.Button(self.container, text="НАЗАД", bg=COLORS["sidebar"], fg="white", font=("Arial", 14), command=self.show_main).pack(side="bottom", pady=40)

if __name__ == "__main__":
    root = tk.Tk(); app = ChastnikApp(root); root.mainloop()
